import React from 'react';
const One = ()=>{
  return(
    <h2>子路由1</h2>
  );
};
export default One;