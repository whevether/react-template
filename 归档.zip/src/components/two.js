import React from 'react';
const Two = ()=>{
  return(
    <h2>子路由2</h2>
  );
};
export default Two;