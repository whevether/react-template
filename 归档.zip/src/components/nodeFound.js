import React from 'react';
// import PropTypes from 'prop-types';
const NotFoundPage = () => {
  // staticContext.notFound = true;
  return <><h1 style={{margin:'0px'}}>没有找到页面.....</h1></>;
};
// NotFoundPage.propTypes = {
//   staticContext: PropTypes.object
// };
export default NotFoundPage;