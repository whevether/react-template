import React from 'react';
const Error401 = ()=>{
  return (
    <div>
      401没有权限
    </div>
  );
};
export default Error401;