const {chalkSuccess} = require('./chalkConfig');
/* eslint-disable no-console */
console.log(chalkSuccess('开始调试模式!!!!'));
